# Data Folder

## Structure

- `raw/`: Contains the original audio files in `.wav` format.
- `processed/`: Contains processed data, such as extracted features in CSV format.

## Instructions

### Downloading the Audio Files

Since the audio files are too large to be directly included in this repository, you can download them from the following link:

**Download Audio Files:** [RAVDESS Audio Files](https://zenodo.org/record/1188976/files/Audio_Speech_Actors_01-24.zip?download=1)

1. **Download the audio files** by clicking the link above.
2. **Extract the downloaded zip file** and move the contents (which should be a series of `.wav` files organized by actor) into the `raw/` folder.

### Preparing the Data

1. Once the audio files are in the `raw/` folder, run `1_preprocessing.ipynb` to process the raw data and save it to the `processed/` folder.
2. The processed data will then be ready for feature extraction and further analysis.

## Data Description

The data consists of audio recordings of actors expressing various emotions. These recordings are used to train the machine learning model to recognize emotions from speech.
