# Results Folder

## Contents

This folder contains the results of the feature extraction, model evaluation, and prediction steps. Key files include:

- `audio_files.csv`: List of audio files and their associated labels.
- `features.csv`: Extracted features from the audio files.
- `confusion_matrix.png`: Confusion matrix showing the performance of the model.
- `evaluation_report.txt`: Detailed evaluation metrics.

## Instructions

1. Run the notebooks in sequence to generate the results.
2. The results will be automatically saved in this folder.
