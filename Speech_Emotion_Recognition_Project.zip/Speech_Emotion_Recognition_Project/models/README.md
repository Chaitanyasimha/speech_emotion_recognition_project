# Models Folder

## Contents

This folder contains the trained machine learning models used for emotion recognition. The models are saved in `.pkl` format using the `joblib` library.

- `emotion_recognition_model.pkl`: The final trained model.

## How to Use

1. Load the model in your Python script or notebook using `joblib.load('path_to_model')`.
2. Use the loaded model to predict emotions from new audio data.